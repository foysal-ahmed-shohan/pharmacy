<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchaseDue extends Model
{
    //
}
