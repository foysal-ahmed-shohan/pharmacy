<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExpenseName extends Model
{
    protected $guarded = [];
}


 // public function expense()
 //    {
 //        return $this->hasmany('App\Expense');
 //    }
// }