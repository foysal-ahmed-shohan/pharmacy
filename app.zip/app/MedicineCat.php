<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MedicineCat extends Model
{
    // Mass Asignment
    protected $guarded = [];

}
