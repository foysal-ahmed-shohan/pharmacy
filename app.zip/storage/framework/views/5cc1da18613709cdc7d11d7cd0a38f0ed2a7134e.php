<?php $__env->startSection('content'); ?>
<!--  <div class="container">

  

</div> -->


<!------ Include the above in your HEAD tag ---------->

<div class="container" style="width: 90%" >
    <div class="print1" id="foysal">
    <div class="row">
        <div class="col-xs-12">
    		<div class="content-dir-item" style="margin-right: 25px;">
    			<td><br><img src="<?php echo e(asset('uploads/company/'.$company->logo)); ?>" width="100" style="margin-bottom: -160px; margin-left: 90%"></td>
    			<h3><?php echo e($company->cname); ?></h3>
                 <p><?php echo e($company->address); ?></p>
                 <p><?php echo e($company->phone); ?>, <?php echo e($company->phone2); ?></p>
                 <p><?php echo e($company->email1); ?>, <?php echo e($company->email2); ?></p>
                 
    			<h3 class="pull-right">Order Information:</h3>
    		</div>
    		<hr>
    		<div class="row">
    			<div class="col-xs-6">
    				<address>
    				<strong>Billed To:</strong><br>
    					Name: <?php echo e($sales->customer->customer_name); ?><br>
                       Address: <?php echo e($sales->customer->customer_address); ?><br>
    					Mobile: <?php echo e($sales->customer->customer_phone); ?><br>
                       Email: <?php echo e($sales->customer->customer_email); ?><br>
    				</address>
    			</div>
    			<div class="col-xs-6 text-right">
    				<address>
        			<strong>Invoice Id: </strong>
    					<?php echo e($sales->invoice_no); ?><br>
    					<strong>Date: </strong>
    					<?php echo e($sales->created_at); ?><br>
    				<!-- 	<?php echo e($sales->id); ?> -->
    				</address>
    			</div>
               
    		</div>
    	<!-- 	<div class="row">
    			<div class="col-xs-6">
    				<address>
    					<strong>Payment Method:</strong><br>
    					Visa ending **** 4242<br>
    					jsmith@email.com
    				</address>
    			</div>
    			
    		</div> -->
    	</div>
    </div>

    
    <div class="row">
    	<div class="col-md-12">
    		<div class="panel panel-default">
    			<div class="panel-heading">
    				<h3 class="panel-title"><strong>Order summary</strong></h3>
    			</div>
    			<div class="panel-body">
    				<div class="table-responsive">
    					<table  class="table table-condensed">
    						<thead>
                                <tr>
        							<td><strong>Item</strong></td>
        							<td class="text-center"><strong>Medicine Name</strong></td>
        							<td class="text-center"><strong>Quantity</strong></td>
        							<td class="text-center"><strong>Price</strong></td>
        							
        							
        							
        							<td class="text-right"><strong>Totals</strong></td>
                                </tr>
    						</thead>
    						<tbody>
    							<?php $__currentLoopData = $salesinfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    							<tr>
    								<td><?php echo e($no++); ?></td>

    								<td class="text-center"><?php echo e($salesinfo->medicine['product_name']); ?></td>
    								<td class="text-center">
                                        <?php echo e($salesinfo->quantity); ?></td>
    								<td class="text-center"><?php echo e($salesinfo->price); ?></td>
    								<td class="text-right"><?php echo e($salesinfo->total_amount); ?></td>
    							</tr>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
                                
    							<tr>
    								
    								<td class="thick-line"></td>
    								<td class="thick-line"></td>
    								<td class="thick-line"></td>
    								<td class="thick-line text-center"><strong>Subtotal</strong></td>
    								<td class="thick-line text-right"><?php echo e($sales->sub_total); ?></td>
    							</tr>
    							<tr>
    								
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Total Vat:</strong></td>
    								<td class="no-line text-right"><?php echo e($sales->total_tax); ?></td>
    							</tr>
                                <tr>
                                   
                                    <td class="no-line"></td>
                                    <td class="no-line"></td>
                                    <td class="no-line"></td>
                                    <td class="no-line text-center"><strong>Total Discount:</strong></td>
                                    <td class="no-line text-right"><?php echo e($sales->total_discount); ?></td>
                                </tr>
    							<tr>
    								
    								<td class="no-line"></td>
    							    <td class="no-line"></td>
    								<td class="no-line"></td>
    								<td class="no-line text-center"><strong>Total</strong></td>
    								<td class="no-line text-right"><?php echo e($sales->grand_total); ?></td>
    							</tr>
    						</tbody>
    					</table>
    				</div>
    			</div>
    		</div>
    	</div>
    </div>
    </div>


    <div class="box-header">

      <a onclick="printContent('foysal');" class="btn btn-danger pull-left">Print</a>
      
      <a onclick="CreatePDFfromHTML('foysal');" id="cmd"  class="btn btn-primary pull-left">PDF</a>
 
      <a href="<?php echo e(url('/sales')); ?>"  class="btn btn-primary pull-left">Back To Invoice</a>
     </div>
    </div>

 <?php $__env->stopSection(); ?>

<!-- <script>
 function CreatePDFfromHTML(foysal) {
    var HTML_Width = $("#foysal").width();
    var HTML_Height = $(".container").height();
    var top_left_margin = 5;
    var PDF_Width = HTML_Width + (top_left_margin * 3);
    var PDF_Height = (PDF_Width * 1.5) + (top_left_margin * 2);
    var canvas_image_width = HTML_Width;
    var canvas_image_height = HTML_Height;

    var totalPDFPages = Math.ceil(HTML_Height / PDF_Height) - 1;

    html2canvas($("#foysal")[0]).then(function (canvas) {
        var imgData = canvas.toDataURL("image/jpeg", 1.0);
        var pdf = new jsPDF('p', 'pt', [PDF_Width, PDF_Height]);
        pdf.addImage(imgData, 'JPG', top_left_margin, top_left_margin, canvas_image_width, canvas_image_height);
        for (var i = 1; i <= totalPDFPages; i++) { 
            pdf.addPage(PDF_Width, PDF_Height);
            pdf.addImage(imgData, 'JPG', top_left_margin, -(PDF_Height*i)+(top_left_margin*4),canvas_image_width,canvas_image_height);
        }
        pdf.save("Your_PDF_Name.pdf");
    
    });
}
</script> -->
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/sales/show.blade.php ENDPATH**/ ?>