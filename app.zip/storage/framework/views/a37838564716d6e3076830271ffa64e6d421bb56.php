  <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar"  style="background-color: #2C3E50!important;">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- Sidebar user panel -->
      <div class="user-panel">
        <div class="pull-left image">
          <img src="<?php echo e(asset('dist/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
        </div>
        <div class="pull-left info">
          <p><?php echo e(Auth::user()->name); ?></p>
          <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
        </div>
      </div>

      <!-- /.search form -->
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li>
          <a href="<?php echo e(url('/dashboard')); ?>">
            <i class="fa fa-dashboard"></i> <span>Dashboard</span>
          </a>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-shopping-cart"></i> <span>Sales</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/sales')); ?>"><i class="fa fa-circle-o"></i>All Sales</a></li>
            <li><a href="<?php echo e(url('/sales/add')); ?>"><i class="fa fa-circle-o"></i>Add Sale</a></li>
            <li><a href="<?php echo e(url('/due/CustomerDue')); ?>"><i class="fa fa-circle-o"></i>Customer Due</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-handshake-o"></i> <span>Customers</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/customers')); ?>"><i class="fa fa-circle-o"></i>All Customers</a></li>
            <li><a href="<?php echo e(url('/customers/add')); ?>"><i class="fa fa-circle-o"></i>Add Customer</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-medkit"></i> <span>Medicine</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/medicine')); ?>"><i class="fa fa-circle-o"></i>All Medicine</a></li>
            <li><a href="<?php echo e(url('/medicine/add')); ?>"><i class="fa fa-circle-o"></i>Add Medicine</a></li>
            <li><a href="<?php echo e(url('/medicine/category')); ?>"><i class="fa fa-circle-o"></i>Medicine Category</a></li>
            <li><a href="<?php echo e(url('/medicine/type')); ?>"><i class="fa fa-circle-o"></i>Medicine Type</a></li>
            <li><a href="<?php echo e(url('/medicine/unit')); ?>"><i class="fa fa-circle-o"></i>Medicine Unit</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-building-o"></i> <span>Manufacturers</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/manufacturers')); ?>"><i class="fa fa-circle-o"></i>All Manufacturers</a></li>
            <li><a href="<?php echo e(url('/manufacturers/add')); ?>"><i class="fa fa-circle-o"></i>Add Manufacturer</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-shopping-basket"></i> <span>Purchase</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/purchase')); ?>"><i class="fa fa-circle-o"></i>All Purchase</a></li>
            <li><a href="<?php echo e(url('/purchase/add')); ?>"><i class="fa fa-circle-o"></i>Add Purchase</a></li>
            <li><a href="<?php echo e(url('due/ManufacturerDue')); ?>"><i class="fa fa-circle-o"></i>Manufacturer Due</a></li>

          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-university"></i> <span>Bank</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/bank')); ?>"><i class="fa fa-circle-o"></i>All Bank</a></li>
            <li><a href="<?php echo e(url('/bank/add')); ?>"><i class="fa fa-circle-o"></i>Add Bank</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-user-plus"></i> <span>Supplier</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/supplier')); ?>"><i class="fa fa-circle-o"></i>All Supplier</a></li>
            <li><a href="<?php echo e(url('/supplier/add')); ?>"><i class="fa fa-circle-o"></i>Add Supplier</a></li>
          </ul>
        </li>
          <li class="treeview">
          <a href="#">
            <i class="fa fa-home"></i> <span>Company Information</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(route('company.index')); ?>"><i class="fa fa-circle-o"></i>Profile</a></li>
            <li><a href="<?php echo e(route('company.create')); ?>"><i class="fa fa-circle-o"></i>Add Information</a></li>
          </ul>
        </li>

          <li>
          <a href="<?php echo e(url('/stock')); ?>">
            <i class="fa fa-medkit"></i> <span>Stock</span>
          </a>
         </li>


         <li class="treeview">
          <a href="#">
            <i class="fa fa-shopping-basket"></i> <span>Account</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo e(url('/account/create')); ?>"><i class="fa fa-circle-o"></i>Expense Head</a></li>
            <li><a href="<?php echo e(url('/expadd')); ?>"><i class="fa fa-circle-o"></i>Add Expense</a></li>
            <li><a href="<?php echo e(url('explist')); ?>"><i class="fa fa-circle-o"></i>Expense List</a></li>
            <li><a href="<?php echo e(url('/income')); ?>"><i class="fa fa-circle-o"></i>Income Statement</a></li>
          </ul>
        </li>


    
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside><?php /**PATH H:\xampp\htdocs\personal_project\pharmacy\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>