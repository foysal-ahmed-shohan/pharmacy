<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">

            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h2 class="box-title">Edit Supplier</h2>
                </div>
                <!-- /.card-header -->

            <!-- form start -->
                <form role="form" action="<?php echo e(route('supplier.update',[$supplier->id])); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="sup_name"><?php echo e(__('Supplier Name *')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" value="<?php echo e($supplier->sup_name); ?>" id="sup_name" name="sup_name" placeholder="Enter Supplier Name">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="sup_phone"><?php echo e(__('Supplier Mobile')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="tel" class="form-control" value="<?php echo e($supplier->sup_phone); ?>" id="sup_phone" name="sup_phone" placeholder="Enter Mobile Mobile" pattern="[0-9]{11}">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="sup_address"><?php echo e(__('Supplier Address')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <textarea class="form-control" name="sup_address" rows="3" placeholder="Enter Supplier Address"><?php echo e($supplier->sup_address); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="sup_details"><?php echo e(__('Supplier Details')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <textarea class="form-control" name="sup_details" rows="3" placeholder="Enter Supplier Details"><?php echo e($supplier->sup_details); ?></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="sup_balance"><?php echo e(__('Previous Balance')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="number" class="form-control" value="<?php echo e($supplier->sup_balance); ?>" id="sup_balance" name="sup_balance" placeholder="Enter Previous Balance">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <div class="col-md-offset-3">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                            <input class="btn btn-warning" type="reset" value="<?php echo e(__('Reset')); ?>">
                        </div>
                    </div>
                </form>
            </div>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/supplier/edit.blade.php ENDPATH**/ ?>