<?php $__env->startSection('content'); ?>

   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Stock List</h3>
                
               </div>
               <!-- /.box-header -->
               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Medicine Name</th>
                        <th>Purchase</th>
                        <th>Sale</th>
                        <th>Available</th>
                        
                     </tr>
                     </thead>
                     <tbody>
                  <?php $__currentLoopData = $medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php $__currentLoopData = $purchase; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

						<?php if($s->medicine_id == $p->medicine_id && $p->medicine_id== $m->id ): ?>
                        <tr>
                           <td><?php echo e($no++); ?></td>
                           <td><?php echo e($m->product_name); ?></td>
                           <td><?php echo e($p->sum); ?></td>
                           <td><?php echo e($s->sum); ?></td>
                           <td><?php echo e($p->sum - $s->sum); ?></td>                         
                        </tr>
                    	<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Medicine Name</th>
                        <th>Purchase</th>
                        <th>Sale</th>
                        <th>Available</th>
                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/stock/index.blade.php ENDPATH**/ ?>