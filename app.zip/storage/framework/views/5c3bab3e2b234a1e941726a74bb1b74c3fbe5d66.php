<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
          <!-- left column -->
          
            <!-- general form elements -->
            <div class="box box-primary">
              <div class="box-header">
                <h3 class="box-title">Add Medicine Type</h3>
              </div>
              <!-- /.card-header -->

                <?php if($errors->any()): ?>
                    <div class="alert alert-warning alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php if($errors->count() == 1): ?>
                            <?php echo e($errors->first()); ?>

                        <?php else: ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
            <?php endif; ?>
              <!-- form start -->
              <form role="form" action="<?php echo e(route('medicine.type_store')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                <div class="box-body">
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="name"><?php echo e(__('Type Name *')); ?></label>
                 </div>
                    <div class="col-md-8">
                    <input type="text" class="form-control" value="<?php echo e(old('name')); ?>" id="name" name="name" placeholder="Enter Type Name">
                 </div>
              </div>
                  </div>
                  </div>

                <div class="box-footer">
                  <div class="col-md-offset-3">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                      <input class="btn btn-warning" type="reset" value="<?php echo e(__('Reset')); ?>">
               </div>
               </div>
              </form>
            </div>
            <!-- /.card -->

          <div class="box">
              <div class="box-header">
                  <h3 class="box-title">All Medicine Type List</h3>
              </div>
              <!-- /.card-header -->
              <div class="box-body">
                  <table class="table table-bordered table-striped">
                      <thead>
                      <tr>
                          <th>SL.</th>
                          <th>Name</th>
                          <th>Status</th>
                          <th>Action</th>
                      </tr>
                      </thead>
                      <tbody>
                      <?php $__currentLoopData = $medicinetype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mtype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($no++); ?></td>
                              <td><?php echo e($mtype->name); ?></td>
                              <td><?php if($mtype->status == '1'): ?> Active <?php else: ?> Inactive <?php endif; ?></td>
                              <td>
                                  <a href="<?php echo e(route('medicine.type_edit',[$mtype->id])); ?>"><button class="btn btn-warning"><i class="fa fa-pencil-square-o"></i></button></a>
                                  <a href="<?php echo e(route('medicine.type_delete',[$mtype->id])); ?>"><button class="btn btn-danger" onClick="return confirm('Are you sure you want to Destroy this data permanently?')"><i class="fa fa-trash-o"></i></button></a>
                              </td>
                          </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                      <tfoot>
                      <tr>
                          <th>SL.</th>
                          <th>Name</th>
                          <th>Status</th>
                          <th>Action</th>
                      </tr>
                      </tfoot>
                  </table>
              </div>
              <!-- /.card-body -->
          </div>
          <!-- /.card -->
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\pharmacy\resources\views/medicine/type.blade.php ENDPATH**/ ?>