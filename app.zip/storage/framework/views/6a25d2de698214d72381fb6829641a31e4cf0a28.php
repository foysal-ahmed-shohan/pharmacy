<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
        
          <!-- left column -->
          
            <!-- general form elements -->
            <div class="box box-primary">
              <div class="box-header">
                <h2 class="box-title">Edit Medicine Category</h2>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="<?php echo e(route('medicine.cat_update',[$mcat->id])); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                <div class="box-body">
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="name"><?php echo e(__('Category Name *')); ?></label>
                 </div>
                    <div class="col-md-8">
                    <input type="text" class="form-control" value="<?php echo e($mcat->name); ?>" id="name" name="name" placeholder="Enter Category Name">
                 </div>
              </div>
                  </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="status"><?php echo e(__('Category Status')); ?></label>
                            </div>
                            <div class="col-md-8">
                                    <label for="radioPrimary1">
                                        <input type="radio" class="flat-red" value="1" <?php echo e($mcat->status == '1' ? 'checked' : ''); ?> id="radioPrimary1" name="status"> Active
                                    </label>
                                    <label for="radioPrimary2">
                                        <input type="radio" class="flat-red" value="0" <?php echo e($mcat->status == '0' ? 'checked' : ''); ?> id="radioPrimary2" name="status"> Inactive
                                    </label>

                            </div>
                        </div>
                    </div>

                  </div>

                <div class="box-footer">
                  <div class="col-md-offset-3">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('Update')); ?></button>
                  <button type="reset" class="btn btn-warning"><?php echo e(__('Reset')); ?></button>
               </div>
               </div>
              </form>
            </div>

    </section>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/medicine/cat_edit.blade.php ENDPATH**/ ?>