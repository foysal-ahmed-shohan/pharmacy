<?php $__env->startSection('content'); ?>
   <!-- Main content -->

   <?php if($ck==0): ?>
   <section class="content">
      <div class="row">
         <div class="col-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Purchase List</h3>

                  <a href="<?php echo e(url('/purchase/add')); ?>" class="btn btn-primary pull-right">Add Purchase</a>
               </div>
               <!-- /.card-header -->

                <form role="form" action="<?php echo e(route('purchase.search')); ?>" method="GET">
               <div class="col-md-12">
                 <div class="col-md-5">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="sale_date"><?php echo e(__('From:')); ?></label>
                                        </div>
                                        <div class="col-md-10">

                                                <div class="input-group date">
                                                    <input type="text" name="from" id="sale_date" value="<?php echo e($date); ?>"class="form-control pull-right datepicker" id="datepicker">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>

                                                </div>

                                        </div>
                                    </div>
                                </div>
                              </div>
                                <div class="col-md-5">
                                 <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="sale_date"><?php echo e(__('To:')); ?></label>
                                        </div>
                                        <div class="col-md-10">

                                                <div class="input-group date">
                                                    <input type="text" name="to" id="sale_date" value="<?php echo e($date); ?>" class="form-control pull-right datepicker" id="datepicker">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                               </div>
                                          </div>
                                    </div>
                                </div>
                           </div>

                           <div class=" col-md-1">
                        <div class="col-md-offset-3">
                               <button type="submit" class="btn btn-default"><?php echo e(__('Search')); ?></button> 
                     </div>
                   </div>  
                  </div>
                </form> 





               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Invoice No</th>
                        <th>Purchase ID</th>
                        <th>Manufacturer Name</th>
                        <th>Date</th>
                        <th>Paymeny Type</th>
                        <th>Total</th>
                        <th>Action</th>


                     </tr>
                     </thead>
                     <tbody>
                     <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($purchase->invoice_no); ?></td>
                        <td><?php echo e($purchase->id); ?></td>
                        <td><?php echo e($purchase->manufacturer->manufacturer_name); ?></td>
                        <td><?php echo e($purchase->purchase_date); ?></td>

                        <td><?php if($purchase->payment_type == '0'): ?> Cash Payment <?php elseif($purchase->payment_type == '1'): ?> Bank Payment <?php else: ?> <span style="color:red;">Due Payment</span> <?php endif; ?></td>
                        <td>৳ <?php echo e(number_format($purchase->grand_total, 2)); ?></td>

                          <td>
                              <a href="<?php echo e(route('purchase.show',['purchase'=>$purchase->id])); ?>">
                              <button class="btn btn-success"><i class="fa fa-eye"></i>
                              </button></a>

                              <a href="<?php echo e(route('purchase.delete',[$purchase->id])); ?>"><button class="btn btn-danger" onClick="return confirm('Are you sure you want to Destroy this data permanently?')"><i class="fa fa-trash-o"></i></button></a>
                           </td>

                     </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Invoice No</th>
                        <th>Purchase ID</th>
                        <th>Manufacturer Name</th>
                        <th>Date</th>
                        <th>Paymeny Type</th>
                        <th>Total</th>

                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.card-body -->
            </div>
            <!-- /.card -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <?php endif; ?>

   <!-- search box start -->
   <?php if($ck==1): ?>
     <section class="content">
      <div class="row">
         <div class="col-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Search List</h3>
                  <a href="<?php echo e(url('/purchase/add')); ?>" class="btn btn-primary pull-right">Add Purchase</a>
               </div>
               <!-- /.card-header -->

                <form role="form" action="<?php echo e(route('purchase.search')); ?>" method="GET">
               <div class="col-md-12">
                 <div class="col-md-5">
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="sale_date"><?php echo e(__('From:')); ?></label>
                                        </div>
                                        <div class="col-md-10">

                                                <div class="input-group date">
                                                    <input type="text" name="from" id="sale_date" value="<?php echo e($date); ?>" class="form-control pull-right datepicker" id="datepicker"  >
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>

                                                </div>

                                        </div>
                                    </div>
                                </div>
                              </div>
                                <div class="col-md-5">
                                 <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="sale_date"><?php echo e(__('To:')); ?></label>
                                        </div>
                                        <div class="col-md-10">

                                                <div class="input-group date">
                                                    <input type="text" name="to" id="sale_date" value="<?php echo e($date); ?>" class="form-control pull-right datepicker" id="datepicker">
                                                    <div class="input-group-addon">
                                                        <i class="fa fa-calendar"></i>
                                                    </div>
                                               </div>
                                          </div>
                                    </div>
                                </div>
                           </div>

                           <div class=" col-md-1">
                        <div class="col-md-offset-3">
                               <button type="submit" class="btn btn-default"><?php echo e(__('Search')); ?></button> 
                     </div>
                   </div>  
                  </div>
                </form>  
                <h3 style="text-align: center; color: #1a75ff  "><strong>Search Result: ( From <?php echo e($from); ?> To <?php echo e($to); ?>)</strong></h3>  

               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Invoice No</th>
                        <th>Purchase ID</th>
                        <th>Manufacturer Name</th>
                        <th>Date</th>
                        <th>Paymeny Type</th>
                        <th>Total</th>
  


                     </tr>
                     </thead>
                     <tbody>
                     <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($no++); ?></td>
                        <td> <a target="blank" href="<?php echo e(route('purchase.show',['purchase'=>$purchase->id])); ?>"><?php echo e($purchase->invoice_no); ?></a></td>
                        <td><?php echo e($purchase->id); ?></td>
                         <td>HASAN</td>
                        <td><?php echo e($purchase->purchase_date); ?></td>

                        <td><?php if($purchase->payment_type == '0'): ?> Cash Payment <?php elseif($purchase->payment_type == '1'): ?> Bank Payment <?php else: ?> <span style="color:red;">Due Payment</span> <?php endif; ?></td>
                        <td>৳ <?php echo e(number_format($purchase->grand_total, 2)); ?></td>

                        

                     </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Invoice No</th>
                        <th>Purchase ID</th>
                        <th>Manufacturer Name</th>
                        <th>Date</th>
                        <th>Paymeny Type</th>
                        <th>Total</th>

                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.card-body -->
            </div>
            <!-- /.card -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <?php endif; ?>

    
   <!-- End search Box -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/purchase/index.blade.php ENDPATH**/ ?>