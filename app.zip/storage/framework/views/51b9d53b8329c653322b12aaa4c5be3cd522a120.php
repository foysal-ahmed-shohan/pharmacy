<?php $__env->startSection('content'); ?>

   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Medicine List</h3>
                  <a href="<?php echo e(url('/medicine/add')); ?>" class="btn btn-primary pull-right">Add Medicine</a>
               </div>
               <!-- /.box-header -->
               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Medicine Name</th>
                        <th>Generic Name</th>
                        <th>Medicine Type</th>
                        <th>Manufacturer</th>
                        <th>Sell Price</th>
                        <th>Purchase Price</th>
                        <th>Unit</th>
                        <th>Box Size</th>
                        <th>Images</th>
                        <th>Action</th>
                     </tr>
                     </thead>
                     <tbody>
                     <?php $__currentLoopData = $medicine; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td><?php echo e($no++); ?></td>
                           <td><?php echo e($medic->product_name); ?></td>
                           <td><?php echo e($medic->generic_name); ?></td>
                           <td><?php echo e($medic->type['name']); ?></td>
                           <td><?php echo e($medic->manufacturer['manufacturer_name']); ?></td>
                           <td><?php echo e($medic->sell_price); ?></td>
                           <td><?php echo e($medic->manufacturer_price); ?></td>
                           <td><?php echo e($medic->unit['name']); ?></td>
                           <td><?php echo e($medic->box_size); ?></td>
                           <td><img src='<?php echo e(asset('uploads/medicine/'.$medic->images)); ?>' width="80"></td>
                           <td>
                              <a href="<?php echo e(route('medicine.edit',[$medic->id])); ?>"><button class="btn btn-warning"><i class="fa fa-pencil-square-o"></i></button></a>
                              <a href="<?php echo e(route('medicine.delete',[$medic->id])); ?>"><button class="btn btn-danger" onClick="return confirm('Are you sure you want to Destroy this data permanently?')"><i class="fa fa-trash-o"></i></button></a>
                           </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Medicine Name</th>
                        <th>Generic Name</th>
                        <th>Medicine Type</th>
                        <th>Manufacturer</th>
                        <th>Sell Price</th>
                        <th>Purchase Price</th>
                        <th>Unit</th>
                        <th>Box Size</th>
                        <th>Images</th>
                        <th>Action</th>
                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/medicine/index.blade.php ENDPATH**/ ?>