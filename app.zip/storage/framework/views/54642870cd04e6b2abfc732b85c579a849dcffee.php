<?php $__env->startSection('content'); ?>

   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h2 class="box-title">Total Sales: <b><?php echo e($sales); ?><b></h2><br>
                  	<h2 class="box-title">Total Sales Due: <b><?php echo e($sales_due); ?><b></h2><br>
                  		<h2 class="box-title">Total Purchase: <b><?php echo e($purchase); ?><b></h2><br>
                  			<h2 class="box-title">Total Purchase Due: <b><?php echo e($parchase_due); ?><b></h2><br>
                  			<h2 class="box-title">Total expense: <b><?php echo e($expense); ?><b></h2><br>
                           <br>
                           <h1 class="box-title">Total Profit: <b><?php echo e(($sales-$sales_due)-($purchase-$parchase_due)-$expense); ?><b></h1><br>

                
               </div>
               <!-- /.box-header -->
               <div class="box-body">
               	 <div class="row">
                  <div class="col-sm-6">
                 
               </div>

           </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>







<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/account/income.blade.php ENDPATH**/ ?>