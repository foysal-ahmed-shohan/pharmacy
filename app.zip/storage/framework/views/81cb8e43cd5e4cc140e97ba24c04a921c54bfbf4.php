<?php $__env->startSection('content'); ?>
   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Supplier List</h3>
                  <a href="<?php echo e(url('/company/create')); ?>" class="btn btn-primary pull-right">Add Information</a>
               </div>
               <!-- /.box-header -->
               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Company Name</th>
                        <th>Tag</th>
                        <th>Mobile 1</th>
                        <th>Mobile 2</th>
                        <th>Email 1</th>
                        <th>Email 2</th>
                        <th>Address</th>
                        <th>Logo</th>
                        <th>Action</th>

                     </tr>
                     </thead>
                     <tbody>
                     <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                           <td><?php echo e($no++); ?></td>
                           <td><?php echo e($comp->cname); ?></td>
                           <td><?php echo e($comp->tag); ?></td>
                           <td><?php echo e($comp->phone); ?></td>
                           <td><?php echo e($comp->phone2); ?></td>
                           <td><?php echo e($comp->email1); ?></td>
                           <td><?php echo e($comp->email2); ?></td>
                           <td><?php echo e($comp->address); ?></td>
                           <td><img src="<?php echo e(asset('uploads/company/'.$comp->logo)); ?>" width="80"></td>
                           <td>
                              <a href="<?php echo e(route('company.edit',[$comp->id])); ?>"><button class="btn btn-warning"><i class="fa fa-pencil-square-o"></i></button></a>

                             <!--  <a href="<?php echo e(route('company.destroy',[$comp->id])); ?>"><button class="btn btn-danger" onClick="return confirm('Are you sure you want toDestroy this data permanently?')"><i class="fa fa-trash-o"></i></button></a> -->

                              <form id="delete-form-<?php echo e($comp->id); ?>" action="<?php echo e(route('company.destroy',$comp->id)); ?>" style="display: none;" method="POST">
                           <?php echo e(csrf_field()); ?>company
                           <?php echo e(method_field('DELETE')); ?>

                       </form>
                       <button type="button" class="btn btn-danger" title="Delete" onclick="if(confirm('Are you sure? You want to delete this?')){
                           event.preventDefault();
                           document.getElementById('delete-form-<?php echo e($comp->id); ?>').submit();
                       }else {
                           event.preventDefault();
                               }"><i class="fa fa-trash-o"></i>
                       </button> 

                            

                           </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                     <tr>
                       <th>SL.</th>
                        <th>Company Name</th>
                        <th>Tag</th>
                        <th>Mobile 1</th>
                        <th>Mobile 2</th>
                        <th>Email 1</th>
                        <th>Email 2</th>
                        <th>Address</th>
                        <th>Logo</th>
                        <th>Action</th>
                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/cominfo/index.blade.php ENDPATH**/ ?>