<?php $__env->startSection('content'); ?>

   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h2 class="box-title">Customer Name: <b><?php echo e($name->customer_name); ?><b></h2>
                     <a href="<?php echo e(url('due/CustomerDue')); ?>" class="btn btn-primary pull-right">All Due Customers</a>
                 <br>
                 <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <?php if($customer->customer_id == $id): ?>
                  	<h2 class="box-title">Total Balance: <b><?php echo e($customer->sum); ?><b></h2>
                 <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               </div>
               <!-- /.box-header -->
               <div class="box-body">
               	 <div class="row">
                  <div class="col-sm-6">
                  <table id="" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL</th>
                        <th>Invoice No</th>
                        <th>Due Amount</th>
                        <th>Date</th>                 
                        
                     </tr>
                     </thead>
                     <tbody>
                    
                       
                     <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sales): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($sales->due_amount>0 && $sales->customer_id==$id): ?>
                     <tr>
                       <th><?php echo e($no++); ?></th>
                        <th><?php echo e($sales->invoice_no); ?></th>
                        <th><?php echo e($sales->due_amount); ?></th>
                        <th><?php echo e($sales->created_at); ?></th>
  
                     </tr>

                       <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	
                     </tbody>
                    
                  </table>
               </div>

             
              <div class="col-sm-6">
                  <table id="" class="table table-bordered table-striped">
                     <thead>
                     <tr>

                        <th>Payment</th>
                        <th>Date</th>                 
                        
                     </tr>
                     </thead>
                     <tbody>
                    
                       
                     <?php $__currentLoopData = $due; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($due->due_amount <0 && $due->customer_id == $id ): ?>
                     <tr>

                        <th><?php echo e($p=abs( $due->due_amount )); ?></th>
                        <th><?php echo e($due->created_at); ?></th>
  
                     </tr>

                       <?php endif; ?>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    	
                     </tbody>
                    
                  </table>
               </div>

           </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>







<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/sales/income.blade.php ENDPATH**/ ?>