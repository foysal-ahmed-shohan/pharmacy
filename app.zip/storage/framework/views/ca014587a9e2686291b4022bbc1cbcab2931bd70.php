<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
          
            <!-- general form elements -->
            <div class="box box-primary">
              <div class="box-header">
                <h2 class="box-title">Add Supplier</h2>
              </div>
              <!-- /.card-header -->

                <?php if($errors->any()): ?>
                    <div class="alert alert-warning alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php if($errors->count() == 1): ?>
                            <?php echo e($errors->first()); ?>

                        <?php else: ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
            <?php endif; ?>
              <!-- form start -->
               <form role="form" action="<?php echo e(route('company.update',[$company->id])); ?>" method="post" enctype="multipart/form-data" >
                  <?php echo e(csrf_field()); ?>

                  <?php echo method_field('put'); ?>
                <div class="box-body">
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_name"><?php echo e(__('Company Name *')); ?></label>
                 </div>
                    <div class="col-md-8">
                    <input type="text" class="form-control" value="<?php echo e($company->cname); ?>" id="cname" name="cname" placeholder="Enter Company Name">
                 </div>
              </div>
                  </div>
                   <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_name"><?php echo e(__('Company Tag Line *')); ?></label>
                 </div>
                    <div class="col-md-8">
                    <input type="text" class="form-control" value="<?php echo e($company->tag); ?>" id="tag" name="tag" placeholder="Enter Company Tag Line">
                 </div>
              </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_phone"><?php echo e(__('phone *')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <input type="tel" class="form-control" value="<?php echo e($company->phone); ?>" id="phone" name="phone" placeholder="Enter Company 1st Mobile Number" pattern="[0-9]{11}">
                 </div>
              </div>
                  </div>
                   <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_phone"><?php echo e(__('Company Mobile 2nd ')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <input type="tel" class="form-control" value="<?php echo e($company->phone2); ?>" id="phone2" name="phone2" placeholder="Company 2nd Mobile Number" pattern="[0-9]{11}">
                 </div>
              </div>
                  </div>
                   <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_address"><?php echo e(__('Company Email 1st *')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <input type="text" class="form-control" id="sel1" value="<?php echo e($company->email1); ?>" placeholder="Enter 1st email" id="email1" name="email1">
                 </div>
              </div>
                  </div>
                    <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_address"><?php echo e(__('Company Email 2nd')); ?></label>
                 </div>
                 <div class="col-md-8">
                     <input type="text" class="form-control" id="email2" value="<?php echo e($company->email2); ?>" placeholder="Enter 2nd email" name="email2">
                 </div>
                 </div>
              </div>
                  
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="sup_address"><?php echo e(__('Company Address')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <textarea class="form-control"  rows="3" placeholder="Company Address" value="<?php echo e($company->address); ?>" name="address"><?php echo e($company->address); ?></textarea>
                 </div>
              </div>
                  </div>
                 <!--    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <label for="sup_details"><?php echo e(__('Logo')); ?></label>
                            </div>
                            <div class="col-md-2">
                                            <?php if("<?php echo e($company->logo); ?>"): ?>
                                                <img src="<?php echo e(asset('uploads/bank/'.$company->logo)); ?>" width="70">
                                            <?php else: ?>
                                                <p>No image found</p>
                                            <?php endif; ?>
                                        </div>
                        </div>
                    </div> -->
                      <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="logo"><?php echo e(__('Signature')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <?php if("<?php echo e($company->logo); ?>"): ?>
                                                <img src="<?php echo e(asset('uploads/company/'.$company->logo)); ?>" width="50">
                                            <?php else: ?>
                                                <p>No image found</p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" value="<?php echo e($company->logo); ?>" name="logo" class="custom-file-input" id="logo">
                                                    <p class="help-block">Change Bank Signature as Images</p>
                                                </div>
                                                <!--     <div class="input-group-append">
                                                         <span class="input-group-text" id="">Upload</span>
                                                     </div>-->
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>

                 
                  </div>

                <div class="box-footer">
                  <div class="col-md-offset-3">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                      <input class="btn btn-warning" type="reset" value="<?php echo e(__('Reset')); ?>">
               </div>
               </div>
              </form>
            </div>
            <!-- /.card -->

    </section>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/cominfo/edit.blade.php ENDPATH**/ ?>