 






<?php $__env->startSection('content'); ?>

   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Expense</h3>
                
               </div>
               <!-- /.box-header -->
               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Expense Name</th>
                        <th>Amount</th>
                        <th>Date</th>
                        <th>Action</th>
                        
                     </tr>
                     </thead>
                     <tbody>
                     
						   <?php $__currentLoopData = $exp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td><?php echo e($no++); ?></td>
                           <td><?php echo e($exp->exp_name); ?></td>
                           <td><?php echo e($exp->amount); ?></td>
                           <td><?php echo e($exp->date); ?></td>
                            <td>                            

                               <form id="delete-form-<?php echo e($exp->id); ?>" action="<?php echo e(route('account.d',$exp->id)); ?>" style="display: none;" method="GET">
                           <?php echo e(csrf_field()); ?>company
                           <?php echo e(method_field('DELETE')); ?>

                       </form>
                       <button type="button" class="btn btn-danger" title="Delete" onclick="if(confirm('Are you sure? You want to delete this?')){
                           event.preventDefault();
                           document.getElementById('delete-form-<?php echo e($exp->id); ?>').submit();
                       }else {
                           event.preventDefault();
                               }"><i class="fa fa-trash-o"></i>
                       </button>

                           </td>
                          
                        </tr>
               
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						 
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Medicine Name</th>
                        <th>Purchase</th>
                        <th>Sale</th>
                        <th>Available</th>
                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/account/all_expense.blade.php ENDPATH**/ ?>