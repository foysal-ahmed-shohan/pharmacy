<?php $__env->startSection('content'); ?>

   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Manufacturers List</h3>
                  <a href="<?php echo e(url('/manufacturers/add')); ?>" class="btn btn-primary pull-right">Add Manufacturer</a>
               </div>
               <!-- /.box-header -->
               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Details</th>
                        <th>Balance</th>
                        <th>Action</th>
                     </tr>
                     </thead>
                     <tbody>
                     <?php $__currentLoopData = $manufacturers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manufacturer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                           <td><?php echo e($no++); ?></td>
                           <td><?php echo e($manufacturer->manufacturer_name); ?></td>
                           <td><?php echo e($manufacturer->manufacturer_mobile); ?></td>
                           <td><?php echo e($manufacturer->manufacturer_address); ?></td>
                           <td><?php echo e($manufacturer->manufacturer_details); ?></td>
                           <td><?php echo e($manufacturer->manufacturer_balance); ?></td>
                           <td>
                              <a href="<?php echo e(route('manufacturers.edit',[$manufacturer->id])); ?>"><button class="btn btn-warning"><i class="fa fa-pencil-square-o"></i></button></a>
                              <a href="<?php echo e(route('manufacturers.delete',[$manufacturer->id])); ?>"><button class="btn btn-danger" onClick="return confirm('Are you sure you want to Destroy this data permanently?')"><i class="fa fa-trash-o"></i></button></a>
                           </td>
                        </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Address</th>
                        <th>Details</th>
                        <th>Balance</th>
                        <th>Action</th>
                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.box-body -->
            </div>
            <!-- /.box -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
   <!-- /.content -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\pharmacy\resources\views/manufacturers/index.blade.php ENDPATH**/ ?>