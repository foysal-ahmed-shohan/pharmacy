<?php $__env->startSection('content'); ?>
   <!-- Main content -->
   <section class="content">
      <div class="row">
         <div class="col-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">All Purchase List</h3>
                  <a href="<?php echo e(url('/purchase/add')); ?>" class="btn btn-primary pull-right">Add Purchase</a>
               </div>
               <!-- /.card-header -->
               <div class="box-body">
                  <table id="baseIT" class="table table-bordered table-striped">
                     <thead>
                     <tr>
                        <th>SL.</th>
                        <th>Invoice No</th>
                        <th>Purchase ID</th>
                        <th>Manufacturer Name</th>
                        <th>Date</th>
                        <th>Paymeny Type</th>
                        <th>Total</th>

                     </tr>
                     </thead>
                     <tbody>
                     <?php $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <tr>
                        <td><?php echo e($no++); ?></td>
                        <td><?php echo e($purchase->invoice_no); ?></td>
                        <td><?php echo e($purchase->id); ?></td>
                        <td><?php echo e($purchase->manufacturer->manufacturer_name); ?></td>
                        <td><?php echo e($purchase->purchase_date); ?></td>

                        <td><?php if($purchase->payment_type == '0'): ?> Cash Payment <?php elseif($purchase->payment_type == '1'): ?> Bank Payment <?php else: ?> <span style="color:red;">Due Payment</span> <?php endif; ?></td>
                        <td>৳ <?php echo e(number_format($purchase->grand_total, 2)); ?></td>

                     </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     </tbody>
                     <tfoot>
                     <tr>
                        <th>SL.</th>
                        <th>Invoice No</th>
                        <th>Purchase ID</th>
                        <th>Manufacturer Name</th>
                        <th>Date</th>
                        <th>Paymeny Type</th>
                        <th>Total</th>

                     </tr>
                     </tfoot>
                  </table>
               </div>
               <!-- /.card-body -->
            </div>
            <!-- /.card -->
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\pharmacy\resources\views/purchase/index.blade.php ENDPATH**/ ?>