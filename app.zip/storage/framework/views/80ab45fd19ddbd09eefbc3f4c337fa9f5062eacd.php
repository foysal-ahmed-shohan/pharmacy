<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
            <!-- left column -->

            <!-- general form elements -->
            <div class="box box-primary">
                <div class="box-header">
                    <h2 class="box-title">Edit Bank</h2>
                </div>
                <!-- /.card-header -->

            <!-- form start -->
                <form role="form" action="<?php echo e(route('bank.update',[$bank->id])); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="box-body">
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="bank_name"><?php echo e(__('Bank Name *')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" value="<?php echo e($bank->bank_name); ?>" id="bank_name" name="bank_name" placeholder="Enter Bank Name">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="ac_name"><?php echo e(__('Account Name *')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" value="<?php echo e($bank->ac_name); ?>" id="ac_name" name="ac_name" placeholder="Enter Account Name">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="ac_no"><?php echo e(__('Account Number *')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" value="<?php echo e($bank->ac_no); ?>" id="ac_no" name="ac_no" placeholder="Enter Account Number">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="branch_name"><?php echo e(__('Branch *')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="text" class="form-control" value="<?php echo e($bank->branch_name); ?>" id="branch_name" name="branch_name" placeholder="Enter Branch">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="bank_sing"><?php echo e(__('Signature')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <?php if("<?php echo e($bank->bank_sing); ?>"): ?>
                                                <img src="<?php echo e(asset('uploads/bank/'.$bank->bank_sing)); ?>" width="50">
                                            <?php else: ?>
                                                <p>No image found</p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-10">
                                            <div class="input-group">
                                                <div class="custom-file">
                                                    <input type="file" value="<?php echo e($bank->bank_sing); ?>" name="bank_sing" class="custom-file-input" id="bank_sing">
                                                    <p class="help-block">Change Bank Signature as Images</p>
                                                </div>
                                                <!--     <div class="input-group-append">
                                                         <span class="input-group-text" id="">Upload</span>
                                                     </div>-->
                                            </div>
                                        </div>
                                    </div>


                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <label for="balance"><?php echo e(__('Opening Balance')); ?></label>
                                </div>
                                <div class="col-md-8">
                                    <input type="number" class="form-control" value="<?php echo e($bank->balance); ?>" id="balance" name="balance" placeholder="Enter Opening Balance">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="box-footer">
                        <div class="col-md-offset-3">
                            <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                            <input class="btn btn-warning" type="reset" value="<?php echo e(__('Reset')); ?>">
                        </div>
                    </div>
                </form>
            </div>
            <!-- /.card -->



    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\pharmacy\resources\views/bank/edit.blade.php ENDPATH**/ ?>