<?php $__env->startSection('content'); ?>
 <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Add New Manufacturer</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">Dashboard</a></li>
              <li class="breadcrumb-item active">Add New Manufacturer</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
          <!-- left column -->
          
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Manufacturer</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="<?php echo e(route('manufacturers.store')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                <div class="card-body">                  
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="manufacturer_name"><?php echo e(__('Manufacturer Name *')); ?></label>
                 </div>
                    <div class="col-md-8">
                    <input type="text" class="form-control" id="manufacturer_name" name="manufacturer_name" placeholder="Enter Manufacturer Name">
                 </div>
              </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="manufacturer_mobile"><?php echo e(__('Manufacturer Mobile')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <input type="tel" class="form-control" id="manufacturer_mobile" name="manufacturer_mobile" placeholder="Enter Manufacturer Mobile" pattern="[0-9]{11}">
                 </div>
              </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="manufacturer_address"><?php echo e(__('Manufacturer Address')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <textarea class="form-control" name="manufacturer_address" rows="3" placeholder="Enter Manufacturer Address"></textarea>
                 </div>
              </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="manufacturer_details"><?php echo e(__('Manufacturer Details')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <textarea class="form-control" rows="3" name="manufacturer_details" placeholder="Enter Manufacturer Details"></textarea>
                 </div>
                 </div>
                  </div>
                  <div class="form-group">
                     <div class="row">
                     <div class="col-md-3">
                    <label for="manufacturer_balance"><?php echo e(__('Previous Balance')); ?></label>
                 </div>
                 <div class="col-md-8">
                    <input type="number" class="form-control" id="manufacturer_balance" name="manufacturer_balance" placeholder="Enter Previous Balance">
                 </div>
              </div>
                  </div>
                  </div>

                <div class="card-footer">
                  <div class="offset-md-3">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                  <button type="submit" class="btn btn-warning"><?php echo e(__('Save and Add Another')); ?></button>
               </div>
               </div>
              </form>
            </div>
            <!-- /.card -->

          

        
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
 <?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\xampp\htdocs\pharmacy\resources\views/manufacturer/add.blade.php ENDPATH**/ ?>