<?php $__env->startSection('content'); ?>
    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        
          <!-- left column -->
          
            <!-- general form elements -->
            <div class="box box-primary">
              <div class="box-header">
                 <a href="<?php echo e(url('/explist')); ?>" class="btn btn-success pull-right">All Expense List</a>
              </div>
              <!-- /.card-header -->

                <?php if($errors->any()): ?>
                    <div class="alert alert-warning alert-dismissible" role="alert">
                        <button type="button" class="close" data-dismiss="alert">&times;</button>
                        <?php if($errors->count() == 1): ?>
                            <?php echo e($errors->first()); ?>

                        <?php else: ?>
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                    </div>
            <?php endif; ?>
              <!-- form start -->
               <form role="form" action="<?php echo e(route('amount.store')); ?>" method="GET" enctype="multipart/form-data">
                  <?php echo csrf_field(); ?>
                   

                   <?php $__currentLoopData = $due; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $due): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					   <?php if($due->customer_id == $id): ?>
	        


                      <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__('Name:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value="<?php echo e($due->customer_name); ?>" id="invoice_no" name="name" placeholder="Enter Invoice No" readonly>
                                        </div>
                                    </div>
                                </div>
                          <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__('Email:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value="<?php echo e($due->customer_email); ?>" id="invoice_no" name="email" placeholder="Enter Invoice No" readonly>
                                        </div>
                                    </div>
                                </div>

                           <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__('Telephone:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value="<?php echo e($due->customer_phone); ?>" id="invoice_no" name="phone" placeholder="Enter Invoice No" readonly>
                                        </div>
                                    </div>
                                </div>

                             <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__('Address:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value="<?php echo e($due->customer_address); ?>" id="address" name="invoice_no" placeholder="Enter Invoice No" readonly>
                                        </div>
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__('Customer ID:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value="<?php echo e($due->customer_id); ?>" id="invoice_no" name="customer_id" placeholder="Enter Invoice No" readonly>
                                        </div>
                                    </div>
                                </div>

                             <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__('Due Amount:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value="<?php echo e($due->sum); ?>" id="invoice_no" name="due" placeholder="Enter Invoice No" readonly>
                                        </div>
                                    </div>
                                </div>


                                   <div class="form-group">
                                    <div class="row">
                                        <div class="col-md-2">
                                            <label for="invoice_no"><?php echo e(__(' Payment:')); ?></label>
                                        </div>
                                        <div class="col-md-8">
                                            <input type="text" class="form-control"
                                         value=" " id="invoice_no" name="amount" placeholder="Enter Invoice No" >
                                        </div>
                                    </div>
                                </div>
                 <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="box-footer">
                  <div class="col-md-offset-3">
                  <button type="submit" class="btn btn-primary"><?php echo e(__('Save')); ?></button>
                      <input class="btn btn-warning" type="reset" value="<?php echo e(__('Reset')); ?>">

               </div>
               </div>
              </form>
            </div>
           
      </div><!-- /.container-fluid -->
    </section>




    <?php $__env->stopSection(); ?>





  
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmacy\resources\views/sales/dueShow.blade.php ENDPATH**/ ?>