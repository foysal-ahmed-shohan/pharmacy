<?php echo e($slot); ?>

<?php /**PATH H:\xampp\htdocs\pharmacy\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>